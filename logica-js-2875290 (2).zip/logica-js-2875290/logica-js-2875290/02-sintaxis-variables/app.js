//crear una variable que se llame "texto" y va a guardar el resultado de
//3+"2"+5+"ocho"
//al final imrpima el resultado en la consola

let num1 = 3
let num2 = "2";
let num3 = 5;
let texto = num1 + num2 + num3
console.log(texto);
console.log(' la suma de 3 + "2" + 5 + "ocho" es' + texto + 'porque no se puede sumar numeros')
