console.log("ejecutando");


//ejercicio 1
// Pedir la altura al usuario
var altura = prompt("Por favor, ingresa tu altura en centímetros:");

// Convertir la entrada a un número entero
altura = parseInt(altura);

// Comparar la altura y mostrar el mensaje correspondiente
if (altura <= 150) {
  alert("Persona de altura baja");
} else if (altura > 150 && altura <= 170) {
  alert("Persona de altura media");
} else {
  alert("Persona alta");
}


//ejercicio 2
// Pedir las notas al usuario
var notaMatematicas = prompt("Ingresa la nota de Matemáticas:");
var notaEspanol = prompt("Ingresa la nota de Español:");
var notaSociales = prompt("Ingresa la nota de Sociales:");

// Convertir las notas a números enteros
notaMatematicas = parseInt(notaMatematicas);
notaEspanol = parseInt(notaEspanol);
notaSociales = parseInt(notaSociales);

// Calcular el promedio
var promedio = (notaMatematicas + notaEspanol + notaSociales) / 3;

// Determinar el mensaje a mostrar según el promedio
if (promedio === 10) {
  alert("Excelente");
} else if (promedio > 7 && promedio <= 10) {
  alert("Bueno");
} else {
  alert("Insuficiente");
}


//ejercicio 3

// Pedir los datos al usuario
var estatura = prompt("Ingresa tu estatura en centímetros:");
var velocidad = prompt("Ingresa tu velocidad en metros por segundo:");
var edad = prompt("Ingresa tu edad:");

// Convertir la entrada a números enteros o flotantes según corresponda
estatura = parseInt(estatura);
velocidad = parseFloat(velocidad);
edad = parseInt(edad);

// Comprobar si cumple con los requisitos para ingresar al equipo
if (estatura >= 180 && velocidad >= 5) {
  if (edad < 18) {
    alert("¡Felicidades! Pasas a las divisiones menores.");
  } else {
    alert("¡Felicidades! Pasas al equipo profesional de mayores.");
  }
} else {
  alert("Lo siento, no cumples con los requisitos para ingresar al equipo.");
}


//ejercicio 4
// Pedir al usuario el número de unidades que está comprando
let unidadesCompradas = prompt("Ingrese el número de unidades que está comprando:");

// Convertir la entrada del usuario a un número entero
unidadesCompradas = parseInt(unidadesCompradas);

// Definir el precio unitario del escritorio
let precioUnitario = 100; // Supongamos que el precio unitario es $100

// Inicializar la variable para almacenar el descuento
let descuento = 0;

// Calcular el descuento según la cantidad de unidades compradas
if (unidadesCompradas < 5) {
  descuento = 0.1; // 10% de descuento
} else if (unidadesCompradas < 10) {
  descuento = 0.2; // 20% de descuento
} else {
  descuento = 0.4; // 40% de descuento
}

// Calcular el monto a pagar por el cliente y el monto del descuento
let montoTotal = unidadesCompradas * precioUnitario;
let montoDescuento = montoTotal * descuento;
let montoAPagar = montoTotal - montoDescuento;

// Mostrar los resultados al usuario
console.log("El cliente debe pagar $" + montoAPagar + " por los escritorios, con un descuento de $" + montoDescuento);


//ejercicio 5
// Mostrar el listado de frutas al usuario
alert("Listado de frutas disponibles:\n- Manzana\n- Plátano\n- Naranja\n- Fresa\n- Uva\n- Piña");

// Pedir a usuario que elija una fruta y la cantidad
var frutaElegida = prompt("Ingresa el nombre de la fruta que deseas comprar:");
var cantidad = prompt("Ingresa la cantidad que deseas comprar:");

// Definir los valores por unidad de cada fruta
var valores = {
  "Manzana": 1400,
  "Plátano": 1000,
  "Naranja": 1200,
  "Fresa": 500,
  "Piña": 2000,
};
// Calcular el valor total de los productos comprados
var valorPorUnidad = valores[frutaElegida];
var total = valorPorUnidad * cantidad;

// Mostrar el nombre de la fruta, valor por unidad y valor total
alert("Fruta: " + frutaElegida + "\nValor por unidad: $" + valorPorUnidad + "\nValor total: $" + total);
